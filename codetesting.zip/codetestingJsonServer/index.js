/*引入json-server*/
const jsonServer = require('json-server');

/*引如db.js输出包*/
const mockData = require("./mock/mockData.js");

console.log(mockData.data);

/*搭建一个server*/
const server = jsonServer.create();

/*将db路由关联到server*/
const router = jsonServer.router(mockData.data);

const middlewares = jsonServer.defaults();

server.use(middlewares);

server.use(router);

//自定义输出
router.render = function(request, response) {	
	response.json({
		code: 0,
		msg: "Scuccess",
		len:30,
		data: response.locals.data
	});
}

/*监听端口*/
server.listen(3000, function() {
	console.log("json Server Start on 3000!");
});