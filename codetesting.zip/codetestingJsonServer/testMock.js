const mockData = require("./mock/mockData.js");
console.log(mockData.data);
