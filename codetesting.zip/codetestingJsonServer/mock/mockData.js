//mockData.js
let Mock = require('mockjs');
function buildData(){
	let data1 = t1Collection();
	let data2 = t2Collection();
	let res = {};
	res['questions'] = data1
	res['otherTopic'] =data2
	return res;
}
function t1Collection(){
	let data = [
		{topic:'发现好题'},
		{collection:[]}
	];
	for (var i = 1; i <= 30; i++) {
		data[1].collection.push(
			Mock.mock({
					'qId':i, // 题目编号
					'qName|1': ['简单输出整数','多项式求值','简单求和','求自定类型元素平均值','简单阶乘计算'], // 题目名字
					'qRequirement': '@cparagraph(1, 3)', // 题目要求
					'qDescribe': '@cparagraph(1, 3)', // 题目描述
					'qSampleInput': '@title(2, 4)', // 题目输入样例
					'qSampleOutput': '@title(2, 4)', // 题目输出样例
					'qPassNummber|1-100': 100, // 通过数量
					'qResponeNumber|1-100': 100, //回答数量
					'qSourceId': Math.floor(i/10)+1, // 题目来源编号
					'qSourceName|1': ['浙大版《C语言程序设计实验与习题指导》--题目集','团体程序设计天体赛--练习集','浙大版《C语言设计》题目集','数据结构与算法题目集','基础编程集'], // 题目来源名字
			})
		);
	}
	return data;
}
function t2Collection(){
	let data = [
		{topic:'基础编程集'},
		{collection:[]}
	];
	for (var i = 1; i <= 30; i++) {
		data[1].collection.push(
			Mock.mock({
				'qId':i, // 题目编号
				'qName|1': ['简单输出整数','多项式求值','简单求和','求自定类型元素平均值','简单阶乘计算'], // 题目名字
				'qRequirement': '@cparagraph(1, 3)', // 题目要求
				'qDescribe': '@cparagraph(1, 3)', // 题目描述
				'qSampleInput': '@title(2, 4)', // 题目输入样例
				'qSampleOutput': '@title(2, 4)', // 题目输出样例
				'qPassNummber|1-100': 100, // 通过数量
				'qResponeNumber|1-100': 100, //回答数量
				'qSourceId': Math.floor(i/10)+1, // 题目来源编号
				'qSourceName': '基础编程集', // 题目来源名字
			})
		);
	}
	return data;
}
module.exports={
	data:buildData()
}
