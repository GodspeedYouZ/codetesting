import Vue from 'vue'
import Vuex from 'vuex'
// store持久化插件
import persistedState from 'vuex-persistedstate'
Vue.use(Vuex)

export default new Vuex.Store({
  plugins: [
    persistedState({
      storage: window.sessionStorage
    })
  ],
  state: {
    xQuestion: {} // 当前问题
  },
  getters: {
    currentQId (state) { // 当前浏览的题号
      return state.xQuestion.qId
    }
  },
  mutations: {
    xSetQuestion (state, question) { // 更新question对象
      state.xQuestion = question
    }
  },
  actions: {
    xIntoCalculate (context, question) { // 进入calculate页面时调用
      context.commit('xSetQuestion', question)
    }
  },
  modules: {
  }
})
