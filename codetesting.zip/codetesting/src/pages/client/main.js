import Vue from 'vue'
import App from './App.vue'
import router from '../../router'
import store from '../../store/client'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import Axios from 'axios'
import VueAxios from 'vue-axios'

Vue.config.productionTip = false
Axios.defaults.baseURL = 'http://localhost:3000'
Vue.use(ElementUI)
Vue.use(VueAxios, Axios)

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
