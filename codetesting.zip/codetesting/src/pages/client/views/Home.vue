<template>
  <div>
    <header>
      <nav-menu></nav-menu>
    </header>
<!--    <router-link></router-link>-->
    <div class="container">
      <router-view/>
    </div>

    <footer>
      <footer-bar></footer-bar>
    </footer>
  </div>
</template>

<script>
// 引入组件
import NavMenu from '../../../components/client/header/NavMenu'
import FooterBar from '../../../components/client/footer/FooterBar'
export default {
// 映射组件标签
  components: {
    NavMenu,
    FooterBar
  }
}
</script>

<style>

</style>
