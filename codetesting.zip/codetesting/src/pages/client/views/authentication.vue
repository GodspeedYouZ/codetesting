<template>
  <div class="a">
    <nav-header></nav-header>
    <div class="wrapper">
      <router-view/>
    </div>
    <nav-copyright></nav-copyright>
  </div>
</template>

<script>
import NavHeader from '../../../components/client/authentication/NavHeader/NavHeader'
import NavCopyright from '../../../components/client/authentication/NavCopyright/NavCopyright'
export default {
  components: {
    NavHeader,
    NavCopyright
  }
}
</script>

<style>
  .a{
    text-align: center;
  }
</style>
