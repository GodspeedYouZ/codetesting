<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style>
#app {
  font-family: "Helvetica Neue",Helvetica,"PingFang SC","Hiragino Sans GB","Microsoft YaHei","微软雅黑",Arial,sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  /*text-align: center;*/
  color: #2c3e50;
}

#nav {
  padding: 30px;
}
/*排版布局*/
body{
  margin: 0;
  min-width: 1200px;
}
header{
  width: 100%;
  min-width: 1350px;
  position: fixed;
  z-index: 2;
}
.container{
  width: calc(100% - 160px);
  top: 80px;
  left: 80px;
  position: relative;
  z-index: 1;
  min-height: 600px;
}
footer{
  position: relative;
  top: 90px;
  width: 100%;
  height: 50px;
  background-color: rgba(185,185,185,0.68);
}
</style>
