import Vue from 'vue'
import VueRouter from 'vue-router'
import cHome from '../pages/client/views/Home'
import cAuthentication from '../pages/client/views/authentication'
Vue.use(VueRouter)

const routes = [
  // admin
  { // 主页
    path: '/admin/',
    name: 'aHome',
    component: () => import('../pages/admin/views/Home')
  },
  {
    path: '/admin/about',
    name: 'a_About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../pages/admin/views/About')
  },
  // client
  { // Home主页
    path: '/',
    name: 'cHome',
    component: cHome,
    children: [
      { // 首页
        path: '/',
        name: 'cHomeContainer',
        component: () => import('../components/client/container/HomeContainer')
      },
      { // 题目集合:类型|题目集合号
        path: '/topicCollection:type',
        name: 'topicCollection',
        component: () => import('../components/client/container/TopicCollection'),
        props: true
      },
      { // 计算页面: 题号
        path: '/calculate:qid',
        name: 'calculate',
        component: () => import('../components/client/container/calculate/Calculate'),
        props: true
      }
    ]
  },
  { // Login登陆页面
    path: '/authentication',
    name: 'authentication',
    component: cAuthentication,
    children: [
      { // 登陆
        path: '/',
        name: 'Login',
        component: () => import('../components/client/authentication/container/Login')
      }, { // 注册
        path: '/authentication/regist',
        name: 'Regist',
        component: () => import('../components/client/authentication/container/Regist')
      }, { // 注册成功页
        path: '/authentication/message',
        name: 'message',
        component: () => import('../components/client/authentication/container/Message')
      }, { // 忘记密码
        path: '/authentication/forget',
        name: 'Forget',
        component: () => import('../components/client/authentication/container/Forget')
      }

    ]
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
