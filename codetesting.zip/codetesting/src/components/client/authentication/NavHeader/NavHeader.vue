<template>
  <div class="header">
    <el-row type="flex" class="row-bg">
      <el-col :span="2"><div class="grid-content bg-purple"></div></el-col>
      <el-col :span="1">
        <div class="grid-content bg-purple">
          <a href=""><img src="../../../../assets/img/login-logo.png" alt=""></a>
        </div>
      </el-col>
      <el-col :span="10">
        <div class="grid-content bg-purple-light">
          <p>
            <span class="mian-title">评测系统</span>
            <span class="subhead">让学习更加有趣，进步变得简单！</span>
          </p>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'NavHeader'
}
</script>

<style lang="stylus" rel="stylesheet/stylus">
.header{
  width :100%;
  height 100px;
  background-color :#fff;
  .row-bg{
    padding: 5px;
  }
}
.row-bg{
  .grid-content{
    p{
      padding :0px 15px;
      text-align :left;
    }
    .mian-title{
      font-family: '微软雅黑 Bold', '微软雅黑 Regular', '微软雅黑';
      font-weight: 700;
      font-size: 34px;
      color: #999999;
    }
    .subhead{
      padding :5px;
      font-family: '微软雅黑';
      font-weight: 400;
      font-size: 20px;
      color: #CCCCCC;
    }
  }
}

</style>
