<template>
  <div class="regist">
    <div class="register-wrapper">
      <div class="line"></div>
      <nav-message v-show="isMessage" :messageInfo="messageInfo"></nav-message>
      <div id="register" v-show="!isMessage">
        <p class="title">新用户注册</p>
        <el-form
          :model="ruleForm2"
          status-icon
          :rules="rules2"
          ref="ruleForm2"
          label-width="0"
          class="ruleForm"
        >
          <el-form-item prop="userName">
            <el-input
              v-model="ruleForm2.userName"
              prefix-icon="el-icon-user-solid"
              placeholder="设置用户名称">
            </el-input>
          </el-form-item>
          <el-form-item prop="tel">
            <el-input
              v-model="ruleForm2.tel"
              prefix-icon="el-icon-phone"
              auto-complete="off"
              placeholder="请输入手机号"
              maxlength="11">
            </el-input>
          </el-form-item>
          <el-form-item prop="smscode" class="code">
            <el-input
              v-model="ruleForm2.smscode"
              prefix-icon="el-icon-chat-dot-round"
              placeholder="验证码"
              style="width: 180px;">
            </el-input>
            <el-button type="primary" :disabled='isDisabled' @click="sendCode">{{buttonText}}</el-button>
          </el-form-item>
          <el-form-item prop="pass">
            <el-input
              type="password"
              prefix-icon="el-icon-lock"
              v-model="ruleForm2.pass"
              auto-complete="off"
              placeholder="输入密码">
            </el-input>
          </el-form-item>
          <el-form-item prop="checkPass">
            <el-input
              type="password"
              prefix-icon="el-icon-lock"
              v-model="ruleForm2.checkPass"
              auto-complete="off"
              placeholder="确认密码">
            </el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm2')" style="width:100%;">注册</el-button>
            <p class="gotoLogin" @click="gotoLogin">已有账号？立即登录</p>
          </el-form-item>
        </el-form>
        </div>
      </div>
  </div>
</template>

<script type="text/ecmascript-6">
import NavMessage from '../NavMessage/NavMessage'
export default {
  name: 'Regist',
  components: {
    NavMessage
  },
  data () {
    // 验证用户名称是否为空
    const checkUserName = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入用户名称'))
      } else {
        callback()
      }
    }
    // 验证手机号是否合法
    const checkTel = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入手机号码'))
      } else if (!this.checkMobile(value)) {
        callback(new Error('手机号码不合法'))
      } else {
        callback()
      }
    }
    // 验证码是否为空
    const checkSmscode = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入手机验证码'))
      } else {
        callback()
      }
    }
    // 验证密码
    const validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        if (this.ruleForm2.checkPass !== '') {
          this.$refs.ruleForm2.validateField('checkPass')
        }
        callback()
      }
    }
    // 二次验证密码
    const validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次输入密码'))
      } else if (value !== this.ruleForm2.pass) {
        callback(new Error('两次输入密码不一致!'))
      } else {
        callback()
      }
    }
    return {
      ruleForm2: {
        userName: '',
        pass: '',
        checkPass: '',
        tel: '',
        smscode: ''
      },
      rules2: {
        userName: [{ validator: checkUserName, trigger: 'change' }],
        pass: [{ validator: validatePass, trigger: 'change' }],
        checkPass: [{ validator: validatePass2, trigger: 'change' }],
        tel: [{ validator: checkTel, trigger: 'change' }],
        smscode: [{ validator: checkSmscode, trigger: 'change' }]
      },
      buttonText: '发送验证码',
      isDisabled: false, // 是否禁止点击发送验证码按钮
      flag: true,
      isMessage: false,
      messageInfo: {
        state: '',
        hint: '',
        describe: ''
      }
    }
  },
  methods: {
    // 发送验证码
    sendCode () {
      const tel = this.ruleForm2.tel
      if (this.checkMobile(tel)) {
        console.log(tel)
        let time = 60
        this.buttonText = '已发送'
        this.isDisabled = true
        if (this.flag) {
          this.flag = false
          const timer = setInterval(() => {
            time--
            this.buttonText = time + ' 秒'
            if (time === 0) {
              clearInterval(timer)
              this.buttonText = '重新获取'
              this.isDisabled = false
              this.flag = true
            }
          }, 1000)
        }
      }
    },
    // <!--提交注册-->
    submitForm (formName) {
      this.$refs[formName].validate(valid => {
        if (valid) {
          // setTimeout(() => {
          // this.$router.push({
          // path: "/message"
          // });
          // }, 400);
          this.messageInfo = {
            state: 0,
            hint: '注册成功',
            describe: '快快加入训练营大展身手吧！'
          }
          this.isMessage = true
        } else {
          console.log('error submit!!')
          return false
        }
      })
    },
    // <!--进入登录页-->
    gotoLogin () {
      this.$router.push({
        path: '/authentication'
      })
    },
    // 验证手机号
    checkMobile (str) {
      const re = /^1\d{10}$/
      if (re.test(str)) {
        return true
      } else {
        return false
      }
    }
  }
}
</script>

<style lang="stylus" rel="stylesheet/stylus">
body{
  background-color #f6f7f9;
}
.register-wrapper {
  .line{
    flex :1
    position :relative
    top :0px
    border-bottom :1px solid rgba(0, 0, 0, 0.2)
  }
}
#register {
  max-width: 340px;
  margin: 20px auto;
  background: #fff;
  padding: 20px 400px;
  position: relative;
  z-index: 9;
  .ruleForm{
    input{
      width: 100%;
      height: 50px;
      padding-left: 40px;
    }
    .el-input__icon{
      height :110%;
      width :35px
      font-size :25px;
    }
  }
}
.copyright{
  padding-top: 80px;
}
.title {
  font-size: 26px;
  line-height: 50px;
  font-weight: bold;
  margin: 10px;
  text-align: center;
}
.el-form-item {
  text-align: center;
}
.gotoLogin {
  margin-top: 10px;
  font-size: 14px;
  line-height: 22px;
  color: #1ab2ff;
  cursor: pointer;
  text-align: left;
  text-indent: 8px;
  width: 160px;
}
.gotoLogin:hover {
  color: #2c2fd6;
}
.code >>> .el-form-item__content {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.code button {
  margin-left: 20px;
  width: 140px;
  text-align: center;
}
.el-button--primary:focus {
  background: #409EFF;
  border-color: #409EFF;
  color: #fff;
}
</style>
