<template>
  <div class="login">
    <div class="wrapper">
      <div class="container">
        <div class="login-form">
          <h3>
            <span class="checked">用户登录</span>
          </h3>
          <div class="input">
            <el-input
              placeholder="请输入帐号"
              prefix-icon="el-icon-user-solid"
              v-model="userName">
            </el-input>
          </div>
          <div class="input">
            <el-input
              placeholder="请输入密码"
              prefix-icon="el-icon-lock"
              v-model="password"
              show-password>
            </el-input>
          </div>
          <div class="btn-box">
          <el-button type="primary" class="btn" :loading="loading">登录</el-button>
          </div>
          <div class="tips">
            <div class="sms"><el-checkbox v-model="checked">记住登录状态</el-checkbox></div>
            <div class="reg">
              <el-link href="/authentication/regist" :underline="false">立即注册</el-link><span>|</span>
              <el-link href="/authentication/forget" :underline="false" >忘记密码？</el-link>
            </div>
          </div>
          <div class="other-login">
            <div class="line"></div>
            <div class="text">其他登录方式</div>
            <div class="line"></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'Login',
  data () {
    return {
      userId: '',
      userName: '',
      password: '',
      checked: false,
      loading: false
    }
  },
  methods: {
  },
  components: {
  }
}
</script>

<style lang="stylus" rel="stylesheet/stylus">
#nav
  padding :0px;
.login{
  &>.container{
    height:50px;
    img{
      width:auto;
      height:100%;
    }
  }
  .wrapper {
    background: url('../../../../assets/img/login-bg.jpg') no-repeat center;
    -moz-background-size: 100% 100%;
    background-size: 100% 100%;

    .container {
      top: 0;

      .login-form {
        box-sizing: border-box;
        padding-left: 31px;
        padding-right: 31px;
        width: 410px;
        height: 510px;
        background-color: #ffffff;
        position: absolute;
        bottom: 29px;
        right: 250px;

        h3 {
          line-height: 23px;
          font-size: 24px;
          text-align: center;
          margin: 40px auto 49px;

          .checked {
            color: #999999;
          }
        }

        .input {
          display: inline-block;
          width: 348px;
          height: 50px;
          margin-bottom: 20px;

          input {
            width: 100%;
            height: 100%;
            padding: 18px;
            padding-left: 40px;
            color: #666666;
            font-size: 14px;
          }

          .el-input__icon {
            height: 110%;
            width: 35px
            font-size: 25px;
          }
        }

        .btn {
          width: 100%;
          line-height: 25px;
          margin-top: 0px;
          font-size: 16px;
          border-radius: 0px;
          // background-color :rgba(26, 188, 156, 1);
        }

        .tips {
          margin-top: 20px;
          display: flex;
          justify-content: space-between;
          font-size: 14px;
          cursor: pointer;

          .sms {
            color: #FF6600;
          }

          .reg {
            color: #999999;

            span {
              margin: 0 7px;
            }
          }
        }

        .other-login {
          display: flex;
          // width:80%;
          margin: 25px auto 24px auto;

          .line {
            flex: 1
            position: relative
            top: -7px
            border-bottom: 1px solid rgba(0, 0, 0, 0.2)
          }

          .text {
            padding: 0 25px
            font-weight: 700
            font-size: 14px
            color: #999999
          }
        }
      }
    }
    .container {
      position: relative
      margin-right: auto
      margin-left: auto
    }
  }
}
</style>
