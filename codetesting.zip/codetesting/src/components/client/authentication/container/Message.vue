<template>
  <div class="message">
    <div class="message-wrapper">
      <div class="line"></div>
      <div class="content">
        <p class="message-state">
          <span class="message-icon"><i :class="state.succeed"></i></span>
        </p>
        <p class="message-hint">{{hint}}</p>
        <p class="message-describe">{{describe}}</p>
        <el-button type="primary" class="btn" @click="gotoLogin">重新登录</el-button>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'Regist',
  components: {
  },
  data () {
    return {
      state: {
        succeed: 'el-icon-finished',
        await: '',
        warning: '',
        error: ''
      },
      hint: '注册成功',
      describe: '快快加入训练营大展身手吧！'
    }
  },
  methods: {
    gotoLogin () {
      setTimeout(() => {
        this.$router.push({
          path: '/authentication'
        })
      }, 400)
    }
  }
}
</script>

<style lang="stylus" rel="stylesheet/stylus">
body{
  background-color #f6f7f9;
}
.message-wrapper {
  .line{
    flex :1
    position :relative
    top :0px
    border-bottom :1px solid rgba(0, 0, 0, 0.2)
  }
  .content{
    max-width: 340px;
    margin: 20px auto;
    height :560px;
    background: #fff;
    padding: 20px 400px;
    position: relative;
    z-index: 9;
    .ruleForm{
      input{
        width: 100%;
        height: 50px;
      }
    }
    .message-state{
      padding: 150px 0px 0px;
    }
    .message-icon{
      font-family: 'FontAwesome';
      font-weight: 400;
      font-size :100px;
      color: #409EFF;
    }
    .message-hint{
      height: 10px;
      font-family: '微软雅黑';
      font-weight: 500;
      font-size: 28px;
    }
    .message-describe{
      font-size: 16px;
      line-height: 36px;
      color :#c3cbd6;
    }
    .btn{
      width :60%
    }
  }
}
</style>
