<template>
  <div class="forget">
    <div class="line"></div>
    <div class="containers w960 mt20">
      <nav-message v-show="isMessage" :messageInfo="messageInfo"></nav-message>
      <div class="processor" v-show="active != 3">
        <el-col :xs="24">
          <el-steps class="mc-ui-flex-start" :active="active"  align-center>
            <el-step v-for="(item,index) in stepData" :key ="index" :title="item.title" >
            </el-step>
          </el-steps>
        </el-col>
      </div>
      <div class="content" v-show="active != 3">
        <el-form label-width="100px" v-show="active === 0" >
          <el-row class="mc-ui-flex-center">
            <el-col :xs="24">
              <el-form-item label="用户名称:">
                <el-input v-model="input" placeholder="手机号码/用户名称">
                </el-input>
              </el-form-item>
              <el-form-item label="验证码:">
                <el-input v-model="input" placeholder="输入图形验证码">
                </el-input>
              </el-form-item>
              <el-form-item >
                <img src="https://www.yooc.me/captcha/image/4b04db7ebf4f2a7a48f5cad3d50da5655707864b/" alt="">
                <a href="JavaScript:;">看不清？换一张</a>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-form label-width="100px" v-show="active === 1">
          <el-row class="mc-ui-flex-center">
            <el-col :xs="24">
              <el-form-item label="用户名:">
                <el-input v-model="input" placeholder="请输入用户名">
                </el-input>
              </el-form-item>
              <el-form-item label="手机号码:">
                <el-input v-model="input" placeholder="请输入手机号码">
                </el-input>
              </el-form-item>
              <el-form-item label="验证码:">
                <el-input
                  prefix-icon="el-icon-chat-dot-round"
                  placeholder="验证码"
                  style="width: 125px;">
                </el-input>
                <el-button type="primary" :disabled='isDisabled' >发送验证码</el-button>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-form label-width="100px" v-show="active === 2">
          <el-row class="mc-ui-flex-center">
            <el-col :xs="24">
              <el-form-item label="新的密码:">
                <el-input v-model="input" placeholder="设置6至20位登录密码">
                </el-input>
              </el-form-item>
              <el-form-item label="重复号码:">
                <el-input v-model="input" placeholder="请再次输入登录密码">
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-button type="primary" @click="next">{{nextTile}}</el-button>
      </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import NavMessage from '../NavMessage/NavMessage.vue'
export default {
  name: 'Forget',
  components: {
    NavMessage
  },
  data () {
    return {
      // 步骤条数据
      active: 0,
      stepData: [
        { index: 0, title: '填写账户名' },
        { index: 1, title: '验证身份' },
        { index: 2, title: '设置密码' },
        { index: 3, title: '完成' }
      ],
      nextTile: '下一步',
      messageInfo: { // 提示组件数据
        state: '',
        hint: '',
        describe: ''
      },
      input: '',
      isDisabled: false,
      isMessage: false
    }
  },
  methods: {
    next () {
      if (this.active++ > 3) this.active = 0
      if (this.active === 3) {
        setTimeout(() => {
          // this.$router.push({
          // path: "/message"
          // });
          this.messageInfo = {
            state: 0,
            hint: '重置成功',
            describe: '快快加入训练营大展身手吧！'
          }
          this.isMessage = true
        }, 100)
      }
    }
  }
}
</script>

<style lang="stylus" rel="stylesheet/stylus">
body{
  background-color #f6f7f9;
}
.forget{
  .line{
    flex :1
    position :relative
    top :0px
    border-bottom :1px solid rgba(0, 0, 0, 0.2)
  }
  .containers{
    // border: 1px solid #C5C5C5;
    border-radius: 2px;
    -webkit-border-radius: 2px;
    -moz-border-radius: 2px;
    box-shadow: 0 0 3px #ccc;
    -webkit-box-shadow: 0 0 3px #ccc;
    background-color: #ffffff;
    .content{
      max-width: 340px;
      height :375px;
      margin: 60px auto 0px;
      padding: 45px 50px;
      input{
        height :50px;
      }
    }
    .processor{
      padding: 60px 70px;
      position: relative;
    }
    .message-wrapper .content .message-state{
      padding :0px;
    }
  }
  .mt20{
    top :40px;
  }
  .w960{
    width: 60%;
    margin :30px auto 0px;
  }
}
</style>
