<template>
	<div class="copyright">
		<div class="content-wrapper">
			<div class="line"></div>
			<div class="feed_copyright" >
				<p>
					<a v-for="(item,index) in blogroll" :key="index" :href="item.url">
						{{item.title}}<span v-show="index!=blogroll.length-1"> | </span>
					</a>
				</p>
			</div>
			<div class="allow-info-box">
				{{copyright}}
			</div>
		</div>
	</div>
</template>

<script type="text/ecmascript-6">
	export default {
		name:'NavCopyright',
		data() {
			return {
				blogroll:[
					{
						title:'关于我们',
						url:'#'
					},
					{
						title:'帮助中心',
						url:'#'
					},
					{
						title:'意见反馈',
						url:'#'
					},
					{
						title:'代码托管',
						url:'#'
					},
					{
						title:'人才招聘',
						url:'#'
					},
					{
						title:'法律条款',
						url:'#'
					},
					{
						title:'开放平台',
						url:'#'
					}
				],
				copyright:'CopyRight @ 评测系统 2019 - 2020'
			};
		}
	};
</script>

<style lang="stylus" rel="stylesheet/stylus">
.copyright
	width :60%;
	margin :0 auto;
	padding-top:80px;
	text-align :center;
	.content-wrapper
		font-family: '微软雅黑';
		color :#999999;
		.line
			flex :1;
			position :relative;
			top :-7px;
			border-bottom :1px solid rgba(0, 0, 0, 0.1);
		.feed_copyright
			a{
				color:#999999;
				font-size :13px;
				display:inline-block;
				text-decoration:none;
			}
			span{
				margin:0 10px;
			}	
		.allow-info-box
			margin-top:13px;
			font-style: normal;
			font-weight :400
			font-size :13px
			line-height :36px
</style>
