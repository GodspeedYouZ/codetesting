<template>
    <div class="main">
        <div class="title">热门话题</div>
        <el-collapse v-model="activeName">
            <el-collapse-item v-for="(item,index) in categories" :key="index" :name="index"
                :title="item.forumTitle">
                <div v-for="(item,idx) in item.forumList" :key="idx" class="content">
                    <span class="column left">标题：{{item.name}}</span>
                    <span class="column center">简介：{{item.synopsis}}</span>
                    <span class="column right">作者：{{item.author}}</span>
                </div>
            </el-collapse-item>
        </el-collapse>
    </div>
</template>

<script>
export default {
  name: 'Forum',
  data () {
    return {
      activeName: '',
      categories: [
        {
          forumTitle: '话题1',
          forumList: [
            {
              name: '第一',
              author: '123',
              synopsis: '我是简介',
              link: ''
            },
            {
              name: '字符超出显示省略号字符超出显示省略号',
              author: '字符超出显示省略号字符超出显示省略号',
              synopsis: '我是超长简介1231231231212113212123121321213213213',
              link: ''
            }
          ]
        },
        {
          forumTitle: '话题2',
          forumList: [
            {
              name: '第一',
              author: '123',
              synopsis: '我是简介',
              link: ''
            },
            {
              name: '第二',
              author: '123',
              synopsis: '我是简介',
              link: ''
            }
          ]
        }
      ]
    }
  }
}
</script>

<style scoped>
    .main {
        clear: left;
        position: relative;
        padding: 2% 0 0 7%;
        width: 80%;
    }
    .title {
        padding-bottom: 1%;
        font: 16px Medium;
    }
    .content {
        position: relative;
        width: 90%;
        left: 5%;
        margin-top: 20px;
        padding: 10px 10px 5px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
        border-radius: 15px;
    }
    .content:hover {
        cursor: pointer;
    }
    .column {
        padding-left: 5%;
        display: inline-block;
    }
    .left {
        width: 20%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space:nowrap ;
    }
    .center {
        width: 40%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space:nowrap ;
    }
    .right {
        float: right;
        padding-right: 5%;
        width: 15%;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space:nowrap ;
    }
</style>
