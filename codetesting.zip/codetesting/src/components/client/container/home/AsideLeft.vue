<template>
    <el-card class="box-card" shadow="always">
        <div slot="header">
            <span style="font: 16px Medium">热门推荐</span>
            <el-button style="float: right; padding: 3px 0" type="text">换一组</el-button>
        </div>
        <div v-for="(item,index) in tipLists" :key="index" class="text item" @click="toLink(item.qSourceId)">
            <i class="el-icon-s-opportunity">{{item.qSourceName}}</i>
        </div>
    </el-card>
</template>

<script>
export default {
  name: 'AsideLeft',
  data () {
    return {
      tipLists: [
        {
          qSourceId: '1',
          qSourceName: '基础编程题目集'
        },
        {
          qSourceId: '2',
          qSourceName: '浙大版《C语言程序设计实验与习题指导（第三版）》题目集'
        },
        {
          qSourceId: '3',
          qSourceName: '浙大版《C语言程序设计(第三版)》题目集'
        },
        {
          qSourceId: '4',
          qSourceName: '团体程序设计天梯赛--练习集'
        },
        {
          qSourceId: '5',
          qSourceName: '数据结构与算法题目集'
        }
      ]
    }
  },
  methods: {
    toLink (link) {
      this.$router.push('/topicCollection:' + link)
    }
  }

}
</script>

<style scoped>
    .box-card {
        float: left;
        width: 20%;
        height: 365px;
        border-radius: 20px;
        margin-left: 2%;
    }
    .text {
        font-size: 14px;
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }

    .item {
        height: 3rem;
        box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
        border-radius: 4px;
        background-color: rgba(0,0,0,0.7);
        margin-bottom: 2%;
        cursor: pointer;
    }
</style>
