<template>
    <div class="main">
        <div class="tip">登录解锁新大陆</div>
        <div class="icon">
            <el-avatar icon="el-icon-user-solid" :size="60" ></el-avatar>
        </div>
        <el-button class="loginButton" type="success" round>登录</el-button>
        <el-divider class="divider"><span style="font-size: 0.7rem">在线测评系统</span></el-divider>
    </div>
</template>

<script>
export default {
  name: 'AsideRight'
}
</script>

<style scoped>
    .main{
        position: relative;
        float: left;
        left: 4%;
        height: 365px;
        width: 15%;
        box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04);
        border-radius: 20px;
        display: flex;
        align-items: center;
        flex-direction: column;
    }
    .tip{
        position: relative;
        top: 10%;
        font: 16px Medium;
    }
    .icon{
        position: relative;
        top: 25%;
    }
    .loginButton{
        position: relative;
        top: 40%;
    }
    .divider{
        position: relative;
        top: 50%;
    }
</style>
