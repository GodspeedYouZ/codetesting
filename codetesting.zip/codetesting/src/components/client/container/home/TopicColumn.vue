<template>
    <div class="main">
        <el-divider class="divider"><div class="title">热门题目</div></el-divider>
        <el-row>
            <el-col :span="4" v-for="(item,index) in topic" :key="index">
                <el-card :body-style="{ padding: '0px' }" class="card">
                    <img src="https://shadow.elemecdn.com/app/element/hamburger.9cf7b091-55e9-11e9-a976-7f4d0b07eef6.png" class="image" >
                    <div class="button" @click="toCalculate(item)">
                        <el-popover placement="top-start" :title="item.qName" width="200" trigger="hover" :content="item.qDescribe">
                            <el-button slot="reference" class="name" >{{item.qName}}</el-button>
                        </el-popover>
                    </div>
                </el-card>
            </el-col>
        </el-row>
    </div>
</template>

<script>
import { mapActions } from 'vuex'
export default {
  name: 'topicColumn',
  data () {
    return {
      topic: [],
      list: []
    }
  },
  methods: {
    getQuestions () {
      this.axios.get('/questions')
        .then(res => {
          this.list = res.data.data[1].collection
          // 取出排名前6的题目放入数组中
          this.topic = this.list.slice(0, 6)
          // console.log(this.topic)
        })
    },
    toCalculate (question) {
      this.xIntoCalculate(question)
      this.$router.push('calculate' + question.qId)
    },
    ...mapActions(
      ['xIntoCalculate'] // 进入计算页面
    )
  },
  created () {
    this.getQuestions()
  }
}
</script>

<style scoped>
    .main {
        clear: left;
        position: relative;
        padding-top: 2%;
    }
    .title {
        padding-bottom: 1%;
        font: 16px Medium;
    }
    .card {
        width: 60%;
        margin-left: 15%;
    }
    .image {
        width: 100%;
        display: block;
    }
    .button {
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
    }
    .name {
        width: 135px;
        overflow: hidden;     /*设置超出的部分进行影藏*/
        text-overflow: ellipsis;     /*设置超出部分使用省略号*/
        white-space:nowrap ;
    }
</style>
