<template>
    <div class="main">
        <el-carousel height="365px">
            <el-carousel-item v-for="(item,index) in bannerUrl" :key="index">
                <img :src="item.bUrl" :alt="item.name">
            </el-carousel-item>
        </el-carousel>
    </div>
</template>

<script>
export default {
  name: 'Banner',
  data () {
    return {
      bannerUrl: [
        {
          name: '',
          bUrl: require('../../../../assets/img/banner1.png')
        },
        {
          name: '',
          bUrl: require('../../../../assets/img/banner2.png')
        }

      ]
    }
  }
}
</script>

<style scoped>
    .main {
        width: 50%;
        position: relative;
        float: left;
        left: 4%;
        margin-right: 4%;
    }
    img {
        height: 100%;
        width: 100%;
        border-radius: 20px;
    }
</style>
