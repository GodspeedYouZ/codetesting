<template>
  <div class="main">
    <div class="title">
      {{topic}}
      <el-input v-model="search" size="medium" placeholder="请输入题目" clearable class="searchInput"></el-input>
    </div>
    <el-table :data="list.filter(data => !search || data.qName.toLowerCase().includes(search.toLowerCase()))" style="width: 85%" max-height="500" stripe>
      <el-table-column prop="qId" label="题目编号" width="100"/>
      <el-table-column prop="qName" label="题目标题" width="400">
        <template v-slot="scope">
          <span @click=toCalculate(scope.row) class="clickable">{{scope.row.qName}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="qSourceName" label="题目来源" width="400" class="clickable">
        <template v-slot="scope">
          <span @click=toTopic(scope.row.qSourceId) class="clickable">{{scope.row.qSourceName}}</span>
        </template>
      </el-table-column>
      <el-table-column prop="qPassNummber" label="通过数量" width="100"/>
      <el-table-column prop="qResponeNumber" label="回答总数" width="100"/>
    </el-table>
  </div>
</template>

<script>
import { mapActions } from 'vuex'
export default {
  name: 'TopicCollection',
  props: {
    type: String
  },
  data () {
    return {
      topic: '',
      list: [],
      search: ''
    }
  },
  methods: {
    // mock测试数据
    getQuestions () {
      let url = ''
      if (this.type === ':discover') {
        url = '/questions'
      } else {
        url = '/otherTopic'
      }
      this.axios.get(url)
        .then(res => {
          this.topic = res.data.data[0].topic
          this.list = res.data.data[1].collection
          // console.log(res.data.data)
        })
    },
    // 跳转路由链接
    toCalculate (question) { // 根据qId传递对象
      // 将被选中的对象放入state
      this.xIntoCalculate(question)
      this.$router.push('calculate' + question.qId)
    },
    toTopic (qSourceId) {
      this.$router.push('topicCollection:' + qSourceId)
    },
    ...mapActions(
      ['xIntoCalculate'] // 进入计算页面
    )
  },
  created () {
    this.getQuestions()
  },
  watch: {
    $route: {
      handler () {
        this.getQuestions()
      }
    }
  }

}
</script>

<style scoped>
  .main{
    position: relative;
    left: 8%;
  }
  .title{
    font-size: large;
    padding: 20px 270px 20px 0;
  }
  .searchInput{
    width: 200px;
    float: right;
  }
  .clickable{
    cursor: pointer;
  }
</style>
