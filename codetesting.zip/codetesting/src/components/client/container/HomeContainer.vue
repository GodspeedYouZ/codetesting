<template>
    <div>
        <aside-left></aside-left>
        <banner></banner>
        <aside-right></aside-right>
        <topic-column></topic-column>
        <forum></forum>
    </div>
</template>

<script>

import AsideLeft from '../../../components/client/container/home/AsideLeft'
import Banner from '../../../components/client/container/home/Banner'
import AsideRight from '../../../components/client/container/home/AsideRight'
import TopicColumn from '../../../components/client/container/home/TopicColumn'
import Forum from '../../../components/client/container/home/Forum'
export default {
  name: 'HomeContainer',
  components: {
    AsideLeft,
    Banner,
    AsideRight,
    TopicColumn,
    Forum
  }
}
</script>

<style scoped>

</style>
