<template>
    <div class="wrap">
      <topic-info :qId="qId"></topic-info>
      <calculate-result></calculate-result>
    </div>
</template>

<script>
import TopicInfo from './TopicInfo'
import CalculateResult from './CalculateResult'
export default {
  name: 'calculate',
  components: {
    TopicInfo,
    CalculateResult
  },
  props: [
    'qId'
  ],
  data () {
    return {
    }
  },
  methods: {
  },
  created () {
  }

}
</script>

<style scoped>
  .wrap{
    position: relative;
    top: 50px;
    padding-left: 10%;
  }

</style>
