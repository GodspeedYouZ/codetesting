<template>
  <div class="main">
    <div class="title">
      请选择语言：
      <el-select v-model="codeLanguage" filterable placeholder="请选择">
        <el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value"/>
      </el-select>
      <el-button type="primary" round class="cButton" @click="compute()">计算</el-button>
    </div>

    <el-input type="textarea" v-model="codeTobeSubmit" class="code" :rows="10" placeholder="请输入内容"/>

    <div class="result">
      <el-collapse-transition>
        <div v-show="showResult">
          <div class="transition-box">
            <div class="sRow">
              <span>{{status.userId.text + ':'}}</span>
              <span>{{status.userId.result}}</span>
            </div>
            <div class="sRow">
              <span>{{status.runningResult.text + ':'}}</span>
              <span>{{status.runningResult.result}}</span>
            </div>
            <div class="sRow">
              <span>{{status.pLanguage.text + ':'}}</span>
              <span>{{status.pLanguage.result}}</span>
            </div>
            <div class="sRow">
              <span>{{status.spaceUsed.text + ':'}}</span>
              <span>{{status.spaceUsed.result}}</span>
            </div>
            <div class="sRow">
              <span>{{status.timeUsed.text + ':'}}</span>
              <span>{{status.timeUsed.result}}</span>
            </div>
            <div class="sRow">
              <span>{{status.codeRow.text + ':'}}</span>
              <span>{{status.codeRow.result}}</span>
            </div>
          </div>
        </div>
      </el-collapse-transition>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CalculateResult',
  data () {
    return {
      codeTobeSubmit: '', // 待提交代码块
      options: [
        {
          value: '选项1',
          label: 'java'
        }, {
          value: '选项2',
          label: 'C'
        }, {
          value: '选项3',
          label: 'C++'
        }, {
          value: '选项4',
          label: 'python'
        }, {
          value: '选项5',
          label: 'PHP'
        }
      ], // 代码选项
      codeLanguage: '', // 代码语言
      showResult: false, // 默认显示测试结果
      status: {
        userId: {
          text: '用户',
          result: '123'
        },
        runningResult: {
          text: '结果',
          result: '通过'
        },
        pLanguage: {
          text: '代码语言',
          result: 'c'
        },
        spaceUsed: {
          text: '所用时间',
          result: '***'
        },
        timeUsed: {
          text: '所用空间',
          result: 'n'
        },
        codeRow: {
          text: '代码行数',
          result: '100'
        }
      } // 代码测试结果
    }
  },
  methods: {
    // 计算代码
    compute () {
      this.showResult = !this.showResult // 显示隐藏
      if (this.showResult === true) { // 显示结果时提交数据

      }
    }
  }
}
</script>

<style scoped>
  .title{
    padding: 30px 0px;
  }
  .main{
    width: 100%;
    padding-bottom: 60px;
  }
  .cButton{
    margin-left: 45%;
  }
  .code{
    width: 60%;
  }
  .result{ /*代码计算结果*/
    position: relative;
    display: inline-block;
    left: 2%;
  }
  .transition-box {
    width: 200px;
    height: 220px;
    border-radius: 4px;
    background-color: rgba(71,132,185,0.68);
    /*text-align: center;*/
    color: #fff;
    padding: 10px 0px 10px 10px;
    box-sizing: border-box;
  }
  .sRow{
    padding-bottom: 10px;
  }
</style>
