<template>
  <div class="main">
    <div class="title">
      {{xQuestion.qName}}
    </div>
    <el-collapse v-model="activeName">
      <el-collapse-item title="题目描述" name="qDescribe">
        <span>{{xQuestion.qDescribe}}</span>
      </el-collapse-item>
      <el-collapse-item title="题目要求" >
        <span>{{xQuestion.qRequirement}}</span>
      </el-collapse-item>
      <el-collapse-item title="输入样例" >
        <span>{{xQuestion.qSampleInput}}</span>
      </el-collapse-item>
      <el-collapse-item title="输出样例" >
        <span>{{xQuestion.qSampleOutput}}</span>
      </el-collapse-item>
    </el-collapse>
  </div>
</template>

<script>
import { mapState, mapGetters } from 'vuex'
export default {
  name: 'TopicInfo',
  props: [
    'qId'
  ],
  data () {
    return {
      activeName: 'qDescribe'
    }
  },
  computed: {
    ...mapGetters(['currentQId']),
    ...mapState(['xQuestion'])
  },
  methods: {
  },
  created () {
  }

}
</script>

<style scoped>
  .title{
    padding-bottom: 50px;
  }
  .main{
    width: 85%;
  }
</style>
