<template>
    <div class="copyright">
        <div class="column">@在线评测系统  (版本：beta1.0 Build:#2020-05-2)</div>
        <div class="column">(c)在线评测小组</div>
    </div>
</template>

<script>
export default {
  name: 'FooterBar'
}
</script>

<style scoped>
    .copyright {
        display: flex;
        align-items: center;
        flex-direction: column;
        justify-content: center;
        font: 12px Extra Small;
    }
    .column {
        margin-top: 0.5%;
    }
</style>
