<template>
    <div>
        <el-input
                placeholder="请输入内容"
                prefix-icon="el-icon-search"
                v-model="input">
        </el-input>
        <el-button type="primary" plain>搜索</el-button>
    </div>
</template>

<script>
export default {
  name: 'SearchBox',
  data () {
    return {
      input: ''
    }
  }
}
</script>

<style scoped>

</style>
