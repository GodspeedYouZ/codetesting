<template>
  <el-menu :default-active="activeIndex" mode="horizontal" router>
    <el-menu-item style="cursor: default"><img class="logo" src="../../../assets/img/logo.jpg" alt="闽江学院"></el-menu-item>
      <el-menu-item index="/">首页</el-menu-item>
      <el-menu-item index="/topicCollection:discover">发现</el-menu-item>
      <el-menu-item index="3">历史纪录</el-menu-item>
      <el-menu-item index="4">关于我们</el-menu-item>
      <el-menu-item class="search-box"><search-box></search-box></el-menu-item>
      <el-menu-item><login-and-register></login-and-register></el-menu-item>
  </el-menu>
</template>

<script>
import SearchBox from '../../../components/client/header/SearchBox'
import LoginAndRegister from '../../../components/client/header/LoginAndRegister'
export default {
  name: 'NavMenu',
  components: {
    SearchBox,
    LoginAndRegister
  },
  props: {

  },
  data () {
    return {
      activeIndex: '/'
    }
  },
  watch: {
  },
  created () {
    // 判断用户访问的路径，更改当前选择的菜单样式
    this.activeIndex = this.$route.path
  }
}
</script>

<style scoped>
    .logo{
        width: 60px;
        height: 50px;
    }
    .el-menu-item{
        padding: 0 3%;

    }
    .search-box{
        padding-right: 10%;
    }
</style>
