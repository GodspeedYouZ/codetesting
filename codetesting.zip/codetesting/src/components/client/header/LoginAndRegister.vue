<template>
    <div>
        <el-row>
            <el-button round>登录</el-button>
            <el-button type="danger" round>注册</el-button>
        </el-row>
    </div>
</template>

<script>
export default {
  name: 'LoginAndRegister'
}
</script>

<style scoped>
    .el-button{
    }
</style>
